from distutils.core import setup

setup(
    name='How to use Python in Silicon Valley',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='www.github.com/wansang93',
    license='Free',
    author='wansang',
    author_email='wansangk93@gmail.com',
    description='sample package'
)
